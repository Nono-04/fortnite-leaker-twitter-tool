 # Leaker Tool

A Discord Bot for Leakers with many Settings.

Features:
- new cosmetics
- shop
- news feed
- staging server update
- blog posts tracker
- ingame bug tracker
- hotfixes

 # Setup and other Important Stuff:
Run the *main.py* file with Python 3 

**DONT DELETE THE CACHE**
