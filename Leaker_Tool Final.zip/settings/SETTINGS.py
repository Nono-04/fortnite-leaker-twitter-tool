""" SETTINGS
What the bot should post on Twitter:
If a Type is True than the Bot post it. (If a Type is False than the Bot dont post it)
"""
new_cosmetics =     True
shop =              True
newsfeed =          True
staging =           True
blogposts =         True
ingamebugmessage =  True
hotfixes =          True
intervall = 30 # Under 15 Seconds is not allowed.


""" TWITTER_TOKEN
Enter here you Twitter Tokens from https://developer.twitter.com/en/apps
"""
TWITTER_TOKEN = {
    "consumer_key":        "xxxxxxxxxxxx",
    "consumer_secret":     "xxxxxxxxxxxx",
    "access_token_key":    "xxxxxxxxxxxx",
    "access_token_secret": "xxxxxxxxxxxx",
}

nopost = False  # A FUNCTION FOR TESTING! Leave it on False or the Bot dont work!!!!